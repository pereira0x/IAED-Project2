#include "proj.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

link novo(char *idReserva, char idVoo[], Data data, int numPassageiros)
{
    link x = (link)malloc(sizeof(struct reserva));
    x->idReserva =
        (char *)malloc(sizeof(char) * (strlen(idReserva) + 1));
    strcpy(x->idReserva, idReserva);
    strcpy(x->idVoo, idVoo);
    x->data = data;
    x->numPassageiros = numPassageiros;
    x->proximo = NULL;
    return x;
}

void print(link cabeca)
{
    link t;
    for (t = cabeca; t != NULL; t = t->proximo)
    {
        printf("%s %d\n", t->idReserva, t->numPassageiros);
    }
}

link insereInicio(link cabeca, char *idReserva, char idVoo[], Data data, int numPassageiros)
{
    link x = novo(idReserva, idVoo, data, numPassageiros);
    x->proximo = cabeca;
    return x; /*retorna a nova "head"*/
}

link insereFim(link cabeca, char *idReserva, char idVoo[], Data data, int numPassageiros)
{
    link x;
    if (cabeca == NULL)
        return novo(idReserva, idVoo, data, numPassageiros);
    for (x = cabeca; x->proximo != NULL; x = x->proximo); /*loop para chegar ao fim da lista*/
    x->proximo = novo(idReserva, idVoo, data, numPassageiros); /*recorrer à função new*/
    return cabeca;
}

link procura(link cabeca, char *idReserva)
{
    link t;
    for (t = cabeca; t != NULL; t = t->proximo)
        if (strcmp(t->idReserva, idReserva) == 0)
            return t;
    return NULL;
}