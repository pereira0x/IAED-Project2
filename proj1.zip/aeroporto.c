#include "proj.h"
#include <stdio.h>
#include <string.h>
/* Funcoes Aeroportos */

int aeroportoInvalido(char id[])
{
    int i;
    for (i = 0; id[i] != '\0'; i++)
        if (!(id[i] >= 'A' && id[i] <= 'Z'))
            return TRUE;
    return FALSE;
}

int encontraAeroporto(char id[])
{
    int i;
    for (i = 0; i < _numAeroportos; i++)
        if (!strcmp(id, _aeroportos[i].id))
            return i;
    return NAO_EXISTE;
}

void mostraAeroporto(int index)
{
    printf("%s %s %s %d\n", _aeroportos[index].id,
           _aeroportos[index].cidade, _aeroportos[index].pais,
           _aeroportos[index].numVoos);
}

int cmpAeroportos(int a, int b)
{
    return (strcmp(_aeroportos[a].id, _aeroportos[b].id) > 0);
}

void listaTodosAeroportos()
{
    int i;
    int indexAeroportos[MAX_NUM_AEROPORTOS];

    for (i = 0; i < _numAeroportos; i++)
        indexAeroportos[i] = i;

    bubbleSort(indexAeroportos, _numAeroportos, cmpAeroportos);

    for (i = 0; i < _numAeroportos; i++)
        mostraAeroporto(indexAeroportos[i]);
}
